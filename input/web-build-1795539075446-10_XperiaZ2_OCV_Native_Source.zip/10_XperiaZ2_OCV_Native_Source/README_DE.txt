XPERIA Z2 OCV NATIVE – VERSION 10
================================

Dieses Paket ist das vollständige Android-Quellprojekt. Es muss wie bisher
über AndroidForge als APK gebaut werden.

VERBINDLICHE FUNKTIONEN
-----------------------
- Bluetooth Classic / RFCOMM SPP-Server, kompatibel mit PC-Version 10.
- Niedrige Latenz und ACK-Protokoll unverändert aus der funktionierenden
  Version 05.
- Messwertframe: cell;voltage;ir + LF
- Löschframe: cell;--;-- + LF
- Antwort: ACK;cell + LF

OBERFLÄCHE VERSION 10
---------------------
- Landscape only, aber automatische 180°-Drehung (sensorLandscape).
- Instrument View: vollständiges Messgerät bleibt sichtbar.
- IR, Voltage und Cell direkt in den drei Displayflächen.
- Displayflächen jetzt schwarz/dunkler für höheren Kontrast.
- Schriftdicke und Position der funktionierenden Darstellung beibehalten.
- Kleine Kopfzeile "OCV MEASUREMENT" mit CONNECTED/WAITING.
- Umschaltung über "LARGE VALUES" / "INSTRUMENT" ohne Neuaufbau der
  Bluetooth-Verbindung.
- EXIT beendet die App sauber; der RFCOMM-Socket wird sofort geschlossen.
- Keine Debugmeldungen auf der Messansicht.

BUILD / INSTALLATION
--------------------
1. Dieses ZIP in AndroidForge importieren.
2. APK bauen.
3. Alte OCV-App auf dem Xperia beenden/deinstallieren.
4. Neue Version-10-APK installieren.
5. App öffnen; Standardrolle SERVER beibehalten.
6. Danach auf Windows die PC-Version 10 über OCV-Start.cmd starten.

Das PC-Paket und dieses Xperia-Paket Version 10 gehören zusammen.
