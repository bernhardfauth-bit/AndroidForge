package de.ocv.xperiaz2;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

final class RfcommManager {
    static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    static final String SERVICE_NAME = "OCV BT3563 Display";
    private static final Charset ASCII = Charset.forName("US-ASCII");

    enum Mode { SERVER, CLIENT }

    interface Listener {
        void onState(String text, boolean connected);
        boolean onMeasurement(MeasurementFrame frame, String rawLine);
        void onProtocolMessage(String text);
    }

    private final BluetoothAdapter adapter;
    private final Listener listener;
    private final Object socketLock = new Object();
    private volatile boolean running;
    private volatile Mode mode = Mode.SERVER;
    private volatile String clientMac;
    private Thread worker;
    private BluetoothSocket activeSocket;
    private BluetoothServerSocket activeServerSocket;

    RfcommManager(Context context, Listener listener) {
        this.adapter = BluetoothAdapter.getDefaultAdapter();
        this.listener = listener;
    }

    boolean isBluetoothAvailable() {
        return adapter != null;
    }

    boolean isBluetoothEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    synchronized void start(Mode requestedMode, String mac) {
        stop();
        mode = requestedMode == null ? Mode.SERVER : requestedMode;
        clientMac = mac;
        running = true;
        worker = new Thread(new Runnable() {
            @Override public void run() { runLoop(); }
        }, "ocv-rfcomm");
        worker.start();
    }

    synchronized void restart(Mode requestedMode, String mac) {
        start(requestedMode, mac);
    }

    synchronized void stop() {
        running = false;
        closeSockets();
        Thread old = worker;
        worker = null;
        if (old != null) old.interrupt();
    }

    List<BluetoothDevice> bondedDevices() {
        List<BluetoothDevice> result = new ArrayList<BluetoothDevice>();
        if (adapter == null) return result;
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded != null) result.addAll(bonded);
        Collections.sort(result, new Comparator<BluetoothDevice>() {
            @Override public int compare(BluetoothDevice a, BluetoothDevice b) {
                String an = safeName(a);
                String bn = safeName(b);
                return an.compareToIgnoreCase(bn);
            }
        });
        return result;
    }

    private void runLoop() {
        if (adapter == null) {
            listener.onState("BLUETOOTH NICHT VERFÜGBAR", false);
            return;
        }
        while (running) {
            if (!adapter.isEnabled()) {
                listener.onState("BLUETOOTH IST AUS", false);
                sleepRetry(2000);
                continue;
            }
            if (mode == Mode.SERVER) runServerOnce(); else runClientOnce();
            if (running) sleepRetry(250);
        }
    }

    private void runServerOnce() {
        BluetoothServerSocket server = null;
        try {
            listener.onState("WARTET AUF WINDOWS · SPP-SERVER", false);
            try {
                server = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID);
            } catch (IOException secureFailure) {
                listener.onProtocolMessage("Sicherer SPP-Server fehlgeschlagen; unsicherer SPP-Fallback.");
                server = adapter.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID);
            }
            synchronized (socketLock) { activeServerSocket = server; }
            BluetoothSocket socket = server.accept();
            synchronized (socketLock) {
                activeSocket = socket;
                activeServerSocket = null;
            }
            closeQuietly(server);
            handleConnection(socket, "WINDOWS VERBUNDEN");
        } catch (IOException ex) {
            if (running) listener.onProtocolMessage("SPP-Server: " + shortMessage(ex));
        } finally {
            synchronized (socketLock) {
                if (activeServerSocket == server) activeServerSocket = null;
            }
            closeQuietly(server);
            closeActiveSocket();
        }
    }

    private void runClientOnce() {
        if (clientMac == null || clientMac.length() == 0) {
            listener.onState("CLIENT: GEKOPPELTEN PC WÄHLEN", false);
            sleepRetry(3000);
            return;
        }
        BluetoothDevice device;
        try {
            device = adapter.getRemoteDevice(clientMac);
        } catch (IllegalArgumentException ex) {
            listener.onState("CLIENT: UNGÜLTIGE PC-ADRESSE", false);
            return;
        }
        BluetoothSocket socket = null;
        try {
            listener.onState("VERBINDE MIT " + safeName(device), false);
            adapter.cancelDiscovery();
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            synchronized (socketLock) { activeSocket = socket; }
            try {
                socket.connect();
            } catch (IOException secureFailure) {
                closeQuietly(socket);
                socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                synchronized (socketLock) { activeSocket = socket; }
                socket.connect();
            }
            handleConnection(socket, "VERBUNDEN MIT " + safeName(device));
        } catch (IOException ex) {
            if (running) listener.onProtocolMessage("SPP-Client: " + shortMessage(ex));
        } finally {
            closeActiveSocket();
        }
    }

    private void handleConnection(BluetoothSocket socket, String state) throws IOException {
        listener.onState(state, true);
        InputStream input = new BufferedInputStream(socket.getInputStream());
        OutputStream output = socket.getOutputStream();
        byte[] buffer = new byte[256];
        StringBuilder line = new StringBuilder();
        while (running) {
            int count = input.read(buffer);
            if (count < 0) throw new IOException("Gegenstelle hat die Verbindung beendet");
            for (int i = 0; i < count; i++) {
                int value = buffer[i] & 0xff;
                if (value == '\n') {
                    processLine(line.toString(), output);
                    line.setLength(0);
                } else if (value != '\r') {
                    if (line.length() < 512) line.append((char) value);
                    else line.setLength(0);
                }
            }
        }
    }

    private void processLine(String rawLine, OutputStream output) throws IOException {
        MeasurementFrame frame = MeasurementFrame.parse(rawLine);
        if (frame == null) {
            listener.onProtocolMessage("Ignoriert: " + rawLine);
            return;
        }
        boolean visible = listener.onMeasurement(frame, rawLine);
        if (!visible) {
            listener.onProtocolMessage("Anzeige-Update fehlgeschlagen; kein ACK.");
            return;
        }
        String ack = "ACK;" + frame.cell + "\n";
        output.write(ack.getBytes(ASCII));
        output.flush();
        listener.onProtocolMessage("Empfangen: " + rawLine + " · Gesendet: " + ack.trim());
    }

    private void closeSockets() {
        synchronized (socketLock) {
            closeQuietly(activeServerSocket);
            activeServerSocket = null;
            closeQuietly(activeSocket);
            activeSocket = null;
        }
    }

    private void closeActiveSocket() {
        synchronized (socketLock) {
            closeQuietly(activeSocket);
            activeSocket = null;
        }
    }

    private void sleepRetry(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    private static String shortMessage(Exception ex) {
        String message = ex.getMessage();
        return message == null ? ex.getClass().getSimpleName() : message;
    }

    private static String safeName(BluetoothDevice device) {
        if (device == null) return "UNBEKANNT";
        String name = device.getName();
        return name == null || name.length() == 0 ? device.getAddress() : name;
    }

    private static void closeQuietly(BluetoothSocket socket) {
        if (socket != null) try { socket.close(); } catch (IOException ignored) { }
    }

    private static void closeQuietly(BluetoothServerSocket socket) {
        if (socket != null) try { socket.close(); } catch (IOException ignored) { }
    }
}
