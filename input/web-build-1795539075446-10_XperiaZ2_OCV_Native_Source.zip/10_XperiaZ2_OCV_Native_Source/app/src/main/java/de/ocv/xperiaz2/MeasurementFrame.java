package de.ocv.xperiaz2;

import java.util.Locale;

final class MeasurementFrame {
    final int cell;
    final String voltageText;
    final String irText;
    final boolean clear;

    private MeasurementFrame(int cell, String voltageText, String irText, boolean clear) {
        this.cell = cell;
        this.voltageText = voltageText;
        this.irText = irText;
        this.clear = clear;
    }

    static MeasurementFrame parse(String line) {
        if (line == null) return null;
        String[] parts = line.trim().split(";", -1);
        if (parts.length != 3) return null;
        try {
            int cell = Integer.parseInt(parts[0].trim());
            String voltageText = parts[1].trim();
            String irText = parts[2].trim();
            if (cell < 0 || cell > 999) return null;
            boolean clear = "--".equals(voltageText) && "--".equals(irText);
            if (clear) return new MeasurementFrame(cell, "--", "--", true);
            if ("--".equals(voltageText) || "--".equals(irText)) return null;
            double voltage = Double.parseDouble(voltageText);
            double ir = Double.parseDouble(irText);
            if (Double.isNaN(voltage) || Double.isInfinite(voltage) || voltage < -1000.0 || voltage > 1000.0) return null;
            if (Double.isNaN(ir) || Double.isInfinite(ir) || ir < 0.0 || ir > 1000000.0) return null;
            if (voltageText.length() > 24 || irText.length() > 24) return null;
            return new MeasurementFrame(cell, voltageText, irText, false);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    String cellTwoDigits() {
        return cell < 100 ? String.format(Locale.US, "%02d", cell) : Integer.toString(cell);
    }

    boolean isReferenceTest() {
        return cell == 7 && "3.77487".equals(voltageText) && "0.8701".equals(irText);
    }
}
