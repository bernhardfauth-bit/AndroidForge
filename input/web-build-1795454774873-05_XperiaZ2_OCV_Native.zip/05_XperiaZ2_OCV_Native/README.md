# Xperia Z2 OCV Native – Bluetooth Classic/RFCOMM

Kleine native Android-App für eine reine Offline-Verbindung zwischen Xperia Z2 und einem bereits gekoppelten Windows-PC.

## Protokoll

- Transport: Bluetooth Classic / RFCOMM / SPP
- UUID: `00001101-0000-1000-8000-00805F9B34FB`
- Kodierung: US-ASCII
- Zeilenende: LF (`0A`), CRLF wird ebenfalls akzeptiert
- PC → Xperia: `Cell;Voltage;IR\n`
- PC → Xperia zum Leeren bei Zellwechsel: `Cell;--;--\n`
- Xperia → PC unmittelbar nach gültigem, für die Anzeige vorgemerktem Frame: `ACK;Cell\n`
- Referenztest: `7;3.77487;0.8701\n` → `ACK;7\n`

Ein Clear-Frame setzt nur Spannung und IR auf `--`; die mitgesendete neue
Zellnummer bleibt sichtbar. Normale Messframes werden nach dem Settlement
angezeigt und beim Abheben der Prüfspitzen durch den Clear-Frame der nächsten
Zelle ersetzt.

## Betriebsarten

- **SERVER (Standard):** Das Xperia veröffentlicht `OCV BT3563 Display`. Windows verbindet sich über einen *ausgehenden* seriellen Bluetooth-COM-Port. Nach Verbindungsabbruch lauscht die App automatisch erneut.
- **CLIENT (Fallback):** Die App verbindet sich mit einem ausgewählten, bereits gekoppelten PC, der selbst einen SPP-Dienst anbietet. Die Auswahl wird gespeichert und automatisch wiederverwendet.

Beide Rollen benutzen dieselbe `RfcommManager`-Implementierung und dieselbe SPP-UUID. Für den mitgelieferten Windows-Test ist **SERVER** vorgesehen.

## Pixelgenaue Xperia-Z2-Darstellung

- Produktionsfläche: exakt `1920 × 1080` Pixel im Xperia-Z2-Querformat
- Hintergrund: `app/src/main/assets/hioki_xperia_1920x1080.png`
- Das Gerätefoto wird auf dem Xperia Z2 1:1 und ohne Bitmap-Filterung gezeichnet.
- Die App benutzt Immersive Fullscreen, damit Android-Navigation und Statusleiste keine Bildpixel abziehen.
- Widerstand/IR steht in der oberen, Spannung in der mittleren und `CELL nn` in der unteren LCD-Zeile.
- Clear-Frames zeigen in den oberen beiden Zeilen `--`; die neue Zellnummer bleibt unten sichtbar.
- Der kleine Linkpunkt am vorhandenen SLOW-Indikator ist grün bei Verbindung und gelb beim Warten.
- Keine zusätzlichen UI-Karten: Das fotografierte **LOAD**-Feld schaltet die Rolle um, das fotografierte **TRIG**-Feld öffnet die Geräteauswahl.

Die mitgelieferte `PREVIEW_05.png` zeigt den Referenzframe
`7;3.77487;0.8701`; `PREVIEW_CLEAR_05.png` zeigt danach `8;--;--`.
Beide verwenden dieselbe 1920-×-1080-Komposition wie die App.

## Kompatibilität

- Optimiert für Sony Xperia Z2 D6503 / D650x mit 1920 × 1080 Pixeln
- `minSdk 19` (Android 4.4 und neuer)
- `targetSdk 28`, damit die klassische Bluetooth-Berechtigungslogik des Xperia erhalten bleibt
- Nur Plattform-APIs, keine AndroidX- oder Internet-Abhängigkeiten zur Laufzeit
- Kein WLAN, PAN, Tethering oder Netzwerkrecht

## Bauen

Auf einem autorisierten Build-Rechner mit Android Studio / Android SDK:

1. Diesen Ordner als Gradle-Projekt öffnen.
2. Gradle-Synchronisierung abwarten.
3. **Build → Build APK(s)**.
4. Die Debug-APK liegt typischerweise unter `app/build/outputs/apk/debug/app-debug.apk` und ist bereits mit dem Android-Debugschlüssel signiert.
5. Für eine dauerhaft updatefähige Verteilung einen eigenen Release-Keystore verwenden.

Für den Firmen-PC ist kein Build vorgesehen; dort wird nur das portable Windows-Testpaket ausgeführt.
