package de.ocv.xperiaz2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.io.InputStream;

/**
 * Pixel-addressed Xperia Z2 presentation layer.
 *
 * The production asset is exactly 1920 x 1080. On the Xperia Z2 in immersive
 * landscape mode it is drawn 1:1 with bitmap filtering disabled. Dynamic values
 * are painted only into the three LCD rows of the photographed instrument.
 */
final class HiokiDisplayView extends View {
    interface ControlListener {
        void onRoleButton();
        void onDeviceButton();
    }

    static final int BASE_WIDTH = 1920;
    static final int BASE_HEIGHT = 1080;

    private static final RectF IR_ROW = new RectF(530f, 349f, 1104f, 486f);
    private static final RectF VOLTAGE_ROW = new RectF(530f, 533f, 1104f, 656f);
    private static final RectF CELL_ROW = new RectF(530f, 669f, 1104f, 793f);

    // Invisible touch targets coincide with the photographed LOAD and TRIG keys.
    private static final RectF ROLE_KEY = new RectF(1540f, 145f, 1720f, 245f);
    private static final RectF DEVICE_KEY = new RectF(1725f, 145f, 1915f, 245f);

    private final Paint bitmapPaint = new Paint();
    private final Paint segmentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ledPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap background;

    private String cellText = "--";
    private String voltageText = "--";
    private String irText = "--";
    private boolean connected;
    private ControlListener controlListener;

    HiokiDisplayView(Context context) {
        super(context);
        bitmapPaint.setFilterBitmap(false);
        bitmapPaint.setDither(false);
        segmentPaint.setColor(Color.rgb(255, 48, 52));
        segmentPaint.setStyle(Paint.Style.FILL);
        segmentPaint.setShadowLayer(8f, 0f, 0f, Color.argb(150, 255, 28, 24));
        ledPaint.setStyle(Paint.Style.FILL);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        Bitmap loaded = null;
        try {
            InputStream in = context.getAssets().open("hioki_xperia_1920x1080.png");
            loaded = BitmapFactory.decodeStream(in);
            in.close();
        } catch (IOException ignored) { }
        background = loaded;
    }

    void setControlListener(ControlListener listener) {
        controlListener = listener;
    }

    void setConnected(boolean value) {
        if (connected != value) {
            connected = value;
            invalidate();
        }
    }

    void showMeasurement(String cell, String voltage, String ir) {
        cellText = safe(cell);
        voltageText = safe(voltage);
        irText = safe(ir);
        invalidate();
    }

    private static String safe(String text) {
        return text == null || text.length() == 0 ? "--" : text.toUpperCase();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale = Math.min(getWidth() / (float) BASE_WIDTH, getHeight() / (float) BASE_HEIGHT);
        float dx = (getWidth() - BASE_WIDTH * scale) * 0.5f;
        float dy = (getHeight() - BASE_HEIGHT * scale) * 0.5f;

        canvas.save();
        canvas.translate(dx, dy);
        canvas.scale(scale, scale);
        canvas.drawColor(Color.rgb(3, 7, 10));
        if (background != null) canvas.drawBitmap(background, 0f, 0f, bitmapPaint);

        drawDisplayText(canvas, irText, IR_ROW, 116f);
        drawDisplayText(canvas, voltageText, VOLTAGE_ROW, 106f);
        drawDisplayText(canvas, "CELL " + cellText, CELL_ROW, 100f);

        // Reuse the instrument's small SLOW indicator as an unobtrusive link LED.
        ledPaint.setColor(connected ? Color.rgb(53, 255, 123) : Color.rgb(255, 178, 38));
        ledPaint.setShadowLayer(5f, 0f, 0f, ledPaint.getColor());
        canvas.drawCircle(899f, 269f, 7f, ledPaint);
        canvas.restore();
    }

    private void drawDisplayText(Canvas canvas, String text, RectF row, float preferredHeight) {
        float height = Math.min(preferredHeight, row.height() - 10f);
        float width = measureText(text, height);
        if (width > row.width() - 10f) {
            height *= (row.width() - 10f) / width;
            width = measureText(text, height);
        }
        float x = row.centerX() - width * 0.5f;
        float y = row.centerY() - height * 0.5f;
        drawText(canvas, text, x, y, height);
    }

    private float measureText(String text, float height) {
        float digitWidth = height * 0.60f;
        float gap = height * 0.105f;
        float total = 0f;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '.') total += height * 0.15f;
            else if (c == ' ') total += height * 0.30f;
            else total += digitWidth;
            if (i + 1 < text.length() && text.charAt(i + 1) != '.') total += gap;
        }
        return total;
    }

    private void drawText(Canvas canvas, String text, float x, float y, float height) {
        float digitWidth = height * 0.60f;
        float gap = height * 0.105f;
        float cursor = x;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '.') {
                float radius = height * 0.055f;
                canvas.drawCircle(cursor + radius, y + height - radius, radius, segmentPaint);
                cursor += height * 0.15f;
            } else if (c == ' ') {
                cursor += height * 0.30f;
            } else {
                drawGlyph(canvas, c, cursor, y, digitWidth, height);
                cursor += digitWidth;
            }
            if (i + 1 < text.length() && text.charAt(i + 1) != '.') cursor += gap;
        }
    }

    private void drawGlyph(Canvas canvas, char c, float x, float y, float width, float height) {
        boolean[] on = segmentsFor(c);
        float t = Math.max(5f, height * 0.095f);
        float mid = height * 0.5f;
        if (on[0]) drawHorizontal(canvas, x, y, width, t);
        if (on[1]) drawVertical(canvas, x + width - t, y, mid, t);
        if (on[2]) drawVertical(canvas, x + width - t, y + mid, mid, t);
        if (on[3]) drawHorizontal(canvas, x, y + height - t, width, t);
        if (on[4]) drawVertical(canvas, x, y + mid, mid, t);
        if (on[5]) drawVertical(canvas, x, y, mid, t);
        if (on[6]) drawHorizontal(canvas, x, y + mid - t * 0.5f, width, t);
    }

    private void drawHorizontal(Canvas canvas, float x, float y, float width, float t) {
        float b = t * 0.42f;
        Path p = new Path();
        p.moveTo(x + b, y);
        p.lineTo(x + width - b, y);
        p.lineTo(x + width, y + t * 0.5f);
        p.lineTo(x + width - b, y + t);
        p.lineTo(x + b, y + t);
        p.lineTo(x, y + t * 0.5f);
        p.close();
        canvas.drawPath(p, segmentPaint);
    }

    private void drawVertical(Canvas canvas, float x, float y, float height, float t) {
        float b = t * 0.42f;
        Path p = new Path();
        p.moveTo(x + t * 0.5f, y);
        p.lineTo(x + t, y + b);
        p.lineTo(x + t, y + height - b);
        p.lineTo(x + t * 0.5f, y + height);
        p.lineTo(x, y + height - b);
        p.lineTo(x, y + b);
        p.close();
        canvas.drawPath(p, segmentPaint);
    }

    // Segment order: top, upper-right, lower-right, bottom, lower-left,
    // upper-left, middle. C/E/L are sufficient for the fixed CELL label.
    private boolean[] segmentsFor(char c) {
        switch (c) {
            case '0': return bits(true, true, true, true, true, true, false);
            case '1': return bits(false, true, true, false, false, false, false);
            case '2': return bits(true, true, false, true, true, false, true);
            case '3': return bits(true, true, true, true, false, false, true);
            case '4': return bits(false, true, true, false, false, true, true);
            case '5': return bits(true, false, true, true, false, true, true);
            case '6': return bits(true, false, true, true, true, true, true);
            case '7': return bits(true, true, true, false, false, false, false);
            case '8': return bits(true, true, true, true, true, true, true);
            case '9': return bits(true, true, true, true, false, true, true);
            case 'C': return bits(true, false, false, true, true, true, false);
            case 'E': return bits(true, false, false, true, true, true, true);
            case 'L': return bits(false, false, false, true, true, true, false);
            case '-': return bits(false, false, false, false, false, false, true);
            default: return bits(false, false, false, false, false, false, false);
        }
    }

    private static boolean[] bits(boolean a, boolean b, boolean c, boolean d,
                                  boolean e, boolean f, boolean g) {
        return new boolean[] { a, b, c, d, e, f, g };
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP || controlListener == null) return true;
        float scale = Math.min(getWidth() / (float) BASE_WIDTH, getHeight() / (float) BASE_HEIGHT);
        float dx = (getWidth() - BASE_WIDTH * scale) * 0.5f;
        float dy = (getHeight() - BASE_HEIGHT * scale) * 0.5f;
        float x = (event.getX() - dx) / scale;
        float y = (event.getY() - dy) / scale;
        if (ROLE_KEY.contains(x, y)) controlListener.onRoleButton();
        else if (DEVICE_KEY.contains(x, y)) controlListener.onDeviceButton();
        return true;
    }
}
