package de.ocv.xperiaz2;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.List;

public final class MainActivity extends Activity implements RfcommManager.Listener {
    private static final int REQUEST_ENABLE_BT = 40;
    private static final String PREFS = "ocv_bt";
    private static final String KEY_MODE = "mode";
    private static final String KEY_MAC = "mac";
    private static final String KEY_NAME = "name";

    private RfcommManager rfcomm;
    private SharedPreferences prefs;
    private RfcommManager.Mode mode;
    private String selectedMac;
    private String selectedName;
    private HiokiDisplayView displayView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        mode = "CLIENT".equals(prefs.getString(KEY_MODE, "SERVER"))
                ? RfcommManager.Mode.CLIENT : RfcommManager.Mode.SERVER;
        selectedMac = prefs.getString(KEY_MAC, null);
        selectedName = prefs.getString(KEY_NAME, "PC WÄHLEN");
        buildUi();
        hideSystemUi();
        rfcomm = new RfcommManager(this, this);
        if (!rfcomm.isBluetoothAvailable()) {
            Toast.makeText(this, "Bluetooth nicht verfügbar.", Toast.LENGTH_LONG).show();
        } else if (!rfcomm.isBluetoothEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (rfcomm != null && rfcomm.isBluetoothEnabled()) rfcomm.start(mode, selectedMac);
    }

    @Override protected void onStop() {
        if (rfcomm != null) rfcomm.stop();
        super.onStop();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        hideSystemUi();
        if (requestCode == REQUEST_ENABLE_BT && rfcomm != null && rfcomm.isBluetoothEnabled()) {
            rfcomm.start(mode, selectedMac);
        }
    }

    private void buildUi() {
        displayView = new HiokiDisplayView(this);
        displayView.setControlListener(new HiokiDisplayView.ControlListener() {
            @Override public void onRoleButton() {
                mode = mode == RfcommManager.Mode.SERVER
                        ? RfcommManager.Mode.CLIENT : RfcommManager.Mode.SERVER;
                prefs.edit().putString(KEY_MODE, mode.name()).apply();
                Toast.makeText(MainActivity.this, "Rolle: " + mode.name(), Toast.LENGTH_SHORT).show();
                if (rfcomm != null) rfcomm.restart(mode, selectedMac);
            }

            @Override public void onDeviceButton() {
                chooseBondedDevice();
            }
        });
        setContentView(displayView);
    }

    private void chooseBondedDevice() {
        final List<BluetoothDevice> devices = rfcomm.bondedDevices();
        if (devices.isEmpty()) {
            Toast.makeText(this, "Keine gekoppelten Bluetooth-Geräte gefunden.", Toast.LENGTH_LONG).show();
            return;
        }
        CharSequence[] labels = new CharSequence[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice device = devices.get(i);
            String name = device.getName();
            labels[i] = (name == null ? "Unbekannt" : name) + "\n" + device.getAddress();
        }
        new AlertDialog.Builder(this)
                .setTitle("Gekoppelten Windows-PC wählen")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        BluetoothDevice device = devices.get(which);
                        selectedMac = device.getAddress();
                        selectedName = device.getName() == null ? selectedMac : device.getName();
                        prefs.edit().putString(KEY_MAC, selectedMac)
                                .putString(KEY_NAME, selectedName).apply();
                        mode = RfcommManager.Mode.CLIENT;
                        prefs.edit().putString(KEY_MODE, mode.name()).apply();
                        rfcomm.restart(mode, selectedMac);
                    }
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    @Override public void onState(final String text, final boolean connected) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                displayView.setConnected(connected);
            }
        });
    }

    @Override public boolean onMeasurement(final MeasurementFrame frame, final String rawLine) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (frame.clear) {
                    displayView.showMeasurement(frame.cellTwoDigits(), "--", "--");
                } else {
                    displayView.showMeasurement(
                            frame.cellTwoDigits(), frame.voltageText, frame.irText);
                }
            }
        });
        return true;
    }

    @Override public void onProtocolMessage(final String text) {
        // The transport/protocol behavior is unchanged. Diagnostics intentionally
        // stay off the photographic measuring-instrument presentation.
    }
}
