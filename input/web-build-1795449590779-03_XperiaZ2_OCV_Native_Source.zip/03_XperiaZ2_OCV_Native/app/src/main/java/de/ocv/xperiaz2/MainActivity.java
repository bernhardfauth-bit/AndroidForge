package de.ocv.xperiaz2;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public final class MainActivity extends Activity implements RfcommManager.Listener {
    private static final int REQUEST_ENABLE_BT = 40;
    private static final String PREFS = "ocv_bt";
    private static final String KEY_MODE = "mode";
    private static final String KEY_MAC = "mac";
    private static final String KEY_NAME = "name";

    private RfcommManager rfcomm;
    private SharedPreferences prefs;
    private RfcommManager.Mode mode;
    private String selectedMac;
    private String selectedName;

    private TextView statusView;
    private TextView diagnosticView;
    private TextView cellView;
    private TextView voltageView;
    private TextView irView;
    private TextView testView;
    private Button roleButton;
    private Button deviceButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        mode = "CLIENT".equals(prefs.getString(KEY_MODE, "SERVER")) ? RfcommManager.Mode.CLIENT : RfcommManager.Mode.SERVER;
        selectedMac = prefs.getString(KEY_MAC, null);
        selectedName = prefs.getString(KEY_NAME, "PC WÄHLEN");
        buildUi();
        rfcomm = new RfcommManager(this, this);
        updateRoleButtons();
        if (!rfcomm.isBluetoothAvailable()) {
            statusView.setText("BLUETOOTH NICHT VERFÜGBAR");
        } else if (!rfcomm.isBluetoothEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (rfcomm != null && rfcomm.isBluetoothEnabled()) rfcomm.start(mode, selectedMac);
    }

    @Override protected void onStop() {
        if (rfcomm != null) rfcomm.stop();
        super.onStop();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT && rfcomm != null && rfcomm.isBluetoothEnabled()) {
            rfcomm.start(mode, selectedMac);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(4, 10, 18));

        ImageView background = new ImageView(this);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        background.setAlpha(0.72f);
        try {
            InputStream in = getAssets().open("hioki_background.jpg");
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            in.close();
            background.setImageBitmap(bitmap);
        } catch (IOException ignored) { }
        root.addView(background, match());

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(12), dp(18), dp(14));
        root.addView(page, match());

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(8), dp(10), dp(8));
        header.setBackground(panel(Color.argb(225, 4, 24, 34), 8));
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(56)));

        statusView = label("STARTET …", 21, Color.rgb(78, 234, 175), Typeface.BOLD);
        header.addView(statusView, new LinearLayout.LayoutParams(0, -1, 1f));

        roleButton = smallButton("");
        roleButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                mode = mode == RfcommManager.Mode.SERVER ? RfcommManager.Mode.CLIENT : RfcommManager.Mode.SERVER;
                prefs.edit().putString(KEY_MODE, mode.name()).apply();
                updateRoleButtons();
                rfcomm.restart(mode, selectedMac);
            }
        });
        header.addView(roleButton, new LinearLayout.LayoutParams(dp(150), dp(42)));

        deviceButton = smallButton("PC WÄHLEN");
        deviceButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { chooseBondedDevice(); }
        });
        LinearLayout.LayoutParams deviceParams = new LinearLayout.LayoutParams(dp(180), dp(42));
        deviceParams.leftMargin = dp(8);
        header.addView(deviceButton, deviceParams);

        diagnosticView = label("SPP " + RfcommManager.SPP_UUID.toString(), 11, Color.rgb(255, 218, 96), Typeface.MONOSPACE.getStyle());
        diagnosticView.setGravity(Gravity.CENTER);
        diagnosticView.setSingleLine(true);
        LinearLayout.LayoutParams diagParams = new LinearLayout.LayoutParams(-1, dp(26));
        diagParams.topMargin = dp(5);
        page.addView(diagnosticView, diagParams);

        LinearLayout values = new LinearLayout(this);
        values.setOrientation(LinearLayout.HORIZONTAL);
        values.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams valuesParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        valuesParams.topMargin = dp(8);
        valuesParams.bottomMargin = dp(8);
        page.addView(values, valuesParams);

        cellView = valueCard("CELL\n--", 42, Color.rgb(255, 83, 92));
        voltageView = valueCard("VOLTAGE\n--", 50, Color.WHITE);
        irView = valueCard("IR\n--", 50, Color.WHITE);
        addValue(values, cellView, 0.82f);
        addValue(values, voltageView, 1.45f);
        addValue(values, irView, 1.20f);

        testView = label("ENDE-ZU-ENDE-TEST: WARTET AUF 7;3.77487;0.8701", 18, Color.WHITE, Typeface.BOLD);
        testView.setGravity(Gravity.CENTER);
        testView.setBackground(panel(Color.argb(230, 82, 48, 0), 8));
        page.addView(testView, new LinearLayout.LayoutParams(-1, dp(46)));

        setContentView(root);
    }

    private void addValue(LinearLayout parent, TextView view, float weight) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -1, weight);
        params.leftMargin = dp(5);
        params.rightMargin = dp(5);
        parent.addView(view, params);
    }

    private TextView valueCard(String text, int size, int color) {
        TextView view = label(text, size, color, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setShadowLayer(5f, 0f, 2f, Color.BLACK);
        view.setBackground(panel(Color.argb(218, 2, 10, 16), 10));
        return view;
    }

    private TextView label(String text, int size, int color, int style) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        return view;
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(12);
        button.setTextColor(Color.WHITE);
        button.setPadding(dp(5), 0, dp(5), 0);
        button.setBackground(panel(Color.rgb(17, 112, 105), 5));
        return button;
    }

    private GradientDrawable panel(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.argb(150, 110, 240, 220));
        return drawable;
    }

    private FrameLayout.LayoutParams match() { return new FrameLayout.LayoutParams(-1, -1); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void updateRoleButtons() {
        if (roleButton == null || deviceButton == null) return;
        roleButton.setText(mode == RfcommManager.Mode.SERVER ? "ROLLE: SERVER" : "ROLLE: CLIENT");
        deviceButton.setText(selectedName == null ? "PC WÄHLEN" : selectedName);
        deviceButton.setVisibility(mode == RfcommManager.Mode.CLIENT ? View.VISIBLE : View.GONE);
    }

    private void chooseBondedDevice() {
        final List<BluetoothDevice> devices = rfcomm.bondedDevices();
        if (devices.isEmpty()) {
            Toast.makeText(this, "Keine gekoppelten Bluetooth-Geräte gefunden.", Toast.LENGTH_LONG).show();
            return;
        }
        CharSequence[] labels = new CharSequence[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice device = devices.get(i);
            String name = device.getName();
            labels[i] = (name == null ? "Unbekannt" : name) + "\n" + device.getAddress();
        }
        new AlertDialog.Builder(this)
                .setTitle("Gekoppelten Windows-PC wählen")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        BluetoothDevice device = devices.get(which);
                        selectedMac = device.getAddress();
                        selectedName = device.getName() == null ? selectedMac : device.getName();
                        prefs.edit().putString(KEY_MAC, selectedMac).putString(KEY_NAME, selectedName).apply();
                        mode = RfcommManager.Mode.CLIENT;
                        prefs.edit().putString(KEY_MODE, mode.name()).apply();
                        updateRoleButtons();
                        rfcomm.restart(mode, selectedMac);
                    }
                })
                .setNegativeButton("Abbrechen", null)
                .show();
    }

    @Override public void onState(final String text, final boolean connected) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                statusView.setText(text);
                statusView.setTextColor(connected ? Color.rgb(75, 244, 158) : Color.rgb(255, 218, 96));
            }
        });
    }

    @Override public boolean onMeasurement(final MeasurementFrame frame, final String rawLine) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                cellView.setText("CELL\n" + frame.cellTwoDigits());
                if (frame.clear) {
                    voltageView.setText("VOLTAGE\n--");
                    irView.setText("IR\n--");
                    testView.setText("BEREIT · CELL " + frame.cellTwoDigits());
                    testView.setTextColor(Color.WHITE);
                    testView.setBackground(panel(Color.argb(235, 0, 70, 100), 8));
                } else if (frame.isReferenceTest()) {
                    voltageView.setText("VOLTAGE\n" + frame.voltageText + " V");
                    irView.setText("IR\n" + frame.irText + " mΩ");
                    testView.setText("ENDE-ZU-ENDE-TEST: PASS · ACK;7");
                    testView.setTextColor(Color.WHITE);
                    testView.setBackground(panel(Color.argb(235, 0, 112, 72), 8));
                } else {
                    voltageView.setText("VOLTAGE\n" + frame.voltageText + " V");
                    irView.setText("IR\n" + frame.irText + " mΩ");
                    testView.setText("LIVE · LETZTER FRAME: " + rawLine);
                    testView.setBackground(panel(Color.argb(235, 0, 70, 100), 8));
                }
            }
        });
        return true;
    }

    @Override public void onProtocolMessage(final String text) {
        runOnUiThread(new Runnable() {
            @Override public void run() { diagnosticView.setText(text); }
        });
    }
}
