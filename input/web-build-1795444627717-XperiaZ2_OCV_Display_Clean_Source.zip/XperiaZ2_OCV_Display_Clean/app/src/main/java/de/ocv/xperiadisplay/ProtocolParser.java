package de.ocv.xperiadisplay;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class ProtocolParser {
    private ProtocolParser() {}

    public static Reading parse(String raw) {
        if (raw == null) throw new IllegalArgumentException("Leerer Datenrahmen");
        String line = raw.trim();
        String[] parts = line.split(";", -1);
        if (parts.length != 3) throw new IllegalArgumentException("Erwartet: Zelle;Spannung;IR");
        int cell;
        BigDecimal voltage;
        BigDecimal ir;
        try {
            cell = Integer.parseInt(parts[0].trim());
            voltage = new BigDecimal(parts[1].trim());
            ir = new BigDecimal(parts[2].trim());
        } catch (RuntimeException ex) {
            throw new IllegalArgumentException("Ungültige Messwerte");
        }
        if (cell < 0 || cell > 999) throw new IllegalArgumentException("Zellnummer außerhalb 0…999");
        if (voltage.abs().compareTo(new BigDecimal("1000")) > 0) throw new IllegalArgumentException("Spannung außerhalb Bereich");
        if (ir.abs().compareTo(new BigDecimal("1000000")) > 0) throw new IllegalArgumentException("IR außerhalb Bereich");
        return new Reading(cell,
                voltage.setScale(5, RoundingMode.HALF_UP).toPlainString(),
                ir.setScale(4, RoundingMode.HALF_UP).toPlainString());
    }

    public static final class Reading {
        public final int cell;
        public final String voltage;
        public final String ir;
        Reading(int cell, String voltage, String ir) {
            this.cell = cell; this.voltage = voltage; this.ir = ir;
        }
        public String cellDisplay() { return cell < 10 ? "0" + cell : Integer.toString(cell); }
        public String ack() { return "ACK;" + cell; }
    }
}
