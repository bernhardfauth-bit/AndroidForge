package de.ocv.xperiadisplay;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class MainActivity extends Activity implements RfcommServer.Listener {
    private InstrumentView display;
    private RfcommServer server;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        display = new InstrumentView(this);
        setContentView(display);
        immersive();
        server = new RfcommServer(this);
    }

    @Override protected void onResume() { super.onResume(); immersive(); server.start(); }
    @Override protected void onDestroy() { server.stop(); super.onDestroy(); }
    @Override public void onWindowFocusChanged(boolean focus) { super.onWindowFocusChanged(focus); if (focus) immersive(); }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onState(final String state, final String detail) {
        ui.post(() -> display.setState(state, detail));
    }

    @Override public String onFrame(String line) {
        try {
            final ProtocolParser.Reading reading = ProtocolParser.parse(line);
            final CountDownLatch rendered = new CountDownLatch(1);
            ui.post(() -> {
                display.setReading(reading);
                display.setState("CONNECTED", "Messdaten werden live übertragen");
                display.post(rendered::countDown);
            });
            rendered.await(700, TimeUnit.MILLISECONDS);
            return reading.ack();
        } catch (Exception ex) {
            final String message = ex.getMessage() == null ? "Ungültige Messdaten" : ex.getMessage();
            ui.post(() -> display.setState("ERROR", message));
            return "ERR;FORMAT";
        }
    }
}
