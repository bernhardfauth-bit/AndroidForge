package de.ocv.xperiadisplay;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RfcommServer {
    public interface Listener {
        void onState(String state, String detail);
        String onFrame(String line);
    }

    private static final String SERVICE_NAME = "OCV BT3563 Display";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final Listener listener;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread worker;
    private volatile BluetoothServerSocket serverSocket;
    private volatile BluetoothSocket clientSocket;

    public RfcommServer(Listener listener) { this.listener = listener; }

    public synchronized void start() {
        if (running.getAndSet(true)) return;
        worker = new Thread(this::runLoop, "ocv-rfcomm-server");
        worker.start();
    }

    public synchronized void stop() {
        running.set(false);
        closeClient();
        closeServer();
        if (worker != null) worker.interrupt();
    }

    private void runLoop() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            listener.onState("ERROR", "Bluetooth ist auf diesem Gerät nicht verfügbar");
            return;
        }
        while (running.get()) {
            if (!adapter.isEnabled()) {
                listener.onState("BLUETOOTH_OFF", "Bluetooth einschalten");
                sleep(1200); continue;
            }
            try {
                listener.onState("WAITING", "Bereit für Windows");
                serverSocket = openServer(adapter);
                clientSocket = serverSocket.accept();
                if (!running.get()) break;
                listener.onState("CONNECTED", "Windows verbunden");
                serve(clientSocket);
            } catch (IOException ex) {
                if (running.get()) listener.onState("RECONNECTING", "Verbindung beendet · automatischer Neuaufbau");
            } finally {
                closeClient(); closeServer();
            }
            sleep(350);
        }
    }

    private BluetoothServerSocket openServer(BluetoothAdapter adapter) throws IOException {
        try {
            return adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID);
        } catch (IOException secureFailure) {
            return adapter.listenUsingInsecureRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID);
        }
    }

    private void serve(BluetoothSocket socket) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
        String line;
        while (running.get() && (line = reader.readLine()) != null) {
            String response = listener.onFrame(line);
            if (response != null && !response.isEmpty()) {
                writer.write(response); writer.write('\n'); writer.flush();
            }
        }
    }

    private void closeClient() {
        BluetoothSocket s = clientSocket; clientSocket = null;
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }
    private void closeServer() {
        BluetoothServerSocket s = serverSocket; serverSocket = null;
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }
    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }
}
