package de.ocv.xperiadisplay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class InstrumentView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private String state = "WAITING";
    private String detail = "Bereit für Windows";
    private String cell = "--", voltage = "--", ir = "--";
    private String updated = "Noch keine Messung";
    private long flashUntil = 0L;

    private final int bg = Color.rgb(5, 13, 18);
    private final int panel = Color.rgb(12, 27, 35);
    private final int panel2 = Color.rgb(15, 34, 43);
    private final int text = Color.rgb(239, 247, 250);
    private final int muted = Color.rgb(139, 159, 169);
    private final int mint = Color.rgb(77, 226, 197);
    private final int amber = Color.rgb(255, 202, 92);
    private final int red = Color.rgb(255, 88, 111);

    public InstrumentView(Context context) { super(context); p.setTypeface(android.graphics.Typeface.create("sans", 0)); }

    public void setState(String newState, String newDetail) {
        state = newState == null ? "WAITING" : newState;
        detail = newDetail == null ? "" : newDetail;
        postInvalidate();
    }

    public void setReading(ProtocolParser.Reading x) {
        cell = x.cellDisplay(); voltage = x.voltage; ir = x.ir;
        updated = "Aktualisiert · " + new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(new Date());
        flashUntil = SystemClock.uptimeMillis() + 450;
        postInvalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,bg,Color.rgb(7,22,28),Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        drawGrid(c,w,h);
        float m=h*0.055f, top=h*0.055f, header=h*0.15f, footer=h*0.12f;
        drawHeader(c,m,top,w-2*m,header);
        float cardsTop=top+header+h*0.035f, cardsH=h-footer-cardsTop-h*0.055f;
        float gap=w*0.016f, available=w-2*m-2*gap;
        float cellW=available*0.205f, voltW=available*0.455f, irW=available-cellW-voltW;
        drawCard(c,m,cardsTop,cellW,cardsH,"ZELLE",cell,"",red,0.46f);
        drawCard(c,m+cellW+gap,cardsTop,voltW,cardsH,"SPANNUNG",voltage,"V",mint,0.34f);
        drawCard(c,m+cellW+gap+voltW+gap,cardsTop,irW,cardsH,"INNENWIDERSTAND",ir,"mΩ",amber,0.37f);
        drawFooter(c,m,h-footer,w-2*m,footer-h*0.035f);
        if (SystemClock.uptimeMillis()<flashUntil) { postInvalidateDelayed(50); }
    }

    private void drawGrid(Canvas c,float w,float h) {
        p.setStrokeWidth(1); p.setColor(Color.argb(24,77,226,197));
        float step=Math.max(36,h/9f);
        for(float x=0;x<w;x+=step)c.drawLine(x,0,x,h,p);
        for(float y=0;y<h;y+=step)c.drawLine(0,y,w,y,p);
        Path path=new Path(); path.moveTo(w*.62f,0); path.lineTo(w*.9f,h); p.setColor(Color.argb(18,255,202,92)); p.setStrokeWidth(3); c.drawPath(path,p);
    }

    private void drawHeader(Canvas c,float x,float y,float w,float h) {
        round(c,x,y,w,h,panel,18);
        p.setColor(mint); p.setTextSize(h*.24f); p.setTypeface(android.graphics.Typeface.create("sans",1));
        c.drawText("OCV · BT3563",x+h*.32f,y+h*.46f,p);
        p.setColor(muted); p.setTextSize(h*.16f); p.setTypeface(android.graphics.Typeface.create("sans",0));
        c.drawText("XPERIA Z2 DISPLAY",x+h*.32f,y+h*.73f,p);
        int color=stateColor(); String label=stateLabel();
        float pillW=Math.max(w*.27f,measure(label,h*.18f)+h*.48f);
        round(c,x+w-pillW-h*.16f,y+h*.19f,pillW,h*.62f,withAlpha(color,38),999);
        p.setColor(color); p.setTextSize(h*.18f); p.setTypeface(android.graphics.Typeface.create("sans",1));
        c.drawCircle(x+w-pillW+h*.16f,y+h*.50f,h*.055f,p);
        c.drawText(label,x+w-pillW+h*.28f,y+h*.56f,p);
    }

    private void drawCard(Canvas c,float x,float y,float w,float h,String label,String value,String unit,int accent,float scale) {
        boolean flash=SystemClock.uptimeMillis()<flashUntil;
        round(c,x,y,w,h,flash?Color.rgb(17,43,48):panel2,20);
        p.setStyle(Paint.Style.STROKE); p.setColor(withAlpha(accent,70)); p.setStrokeWidth(Math.max(2,h*.012f));
        r.set(x,y,x+w,y+h); c.drawRoundRect(r,20,20,p); p.setStyle(Paint.Style.FILL);
        p.setColor(accent); p.setTextSize(Math.min(h*.105f,w*.085f)); p.setTypeface(android.graphics.Typeface.create("sans",1));
        c.drawText(label,x+w*.08f,y+h*.16f,p);
        p.setColor(text); p.setTextSize(Math.min(h*scale,w*(label.equals("ZELLE")?.39f:.21f))); p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.create("sans",1));
        float base=y+h*(unit.isEmpty()?.64f:.59f); c.drawText(value,x+w*.50f,base,p);
        if(!unit.isEmpty()) { p.setTextSize(Math.min(h*.16f,w*.14f)); p.setColor(muted); c.drawText(unit,x+w*.50f,y+h*.83f,p); }
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawFooter(Canvas c,float x,float y,float w,float h) {
        int color=stateColor(); round(c,x,y,w,h,withAlpha(color,25),16);
        p.setColor(color); p.setTextSize(h*.27f); p.setTypeface(android.graphics.Typeface.create("sans",1));
        c.drawText(detail,x+h*.28f,y+h*.47f,p);
        p.setColor(muted); p.setTextSize(h*.21f); p.setTypeface(android.graphics.Typeface.create("sans",0));
        c.drawText(updated,x+h*.28f,y+h*.76f,p);
    }

    private int stateColor(){ if("CONNECTED".equals(state))return mint; if("ERROR".equals(state)||"BLUETOOTH_OFF".equals(state))return red; return amber; }
    private String stateLabel(){ if("CONNECTED".equals(state))return "VERBUNDEN"; if("RECONNECTING".equals(state))return "NEUVERBINDUNG"; if("BLUETOOTH_OFF".equals(state))return "BLUETOOTH AUS"; if("ERROR".equals(state))return "FEHLER"; return "WARTET AUF WINDOWS"; }
    private void round(Canvas c,float x,float y,float w,float h,int color,float rad){ p.setStyle(Paint.Style.FILL);p.setColor(color);r.set(x,y,x+w,y+h);c.drawRoundRect(r,rad,rad,p); }
    private float measure(String s,float size){p.setTextSize(size);return p.measureText(s);}
    private static int withAlpha(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}
}
