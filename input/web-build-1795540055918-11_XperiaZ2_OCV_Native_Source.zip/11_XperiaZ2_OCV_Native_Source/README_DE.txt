XPERIA Z2 OCV DISPLAY — VERSION 11 SERVER-HOTFIX
================================================

1. Dieses Projekt mit AndroidForge als APK bauen.
2. Die APK über die bisher verwendete Bluetooth-Dateiübertragung installieren.
3. App öffnen und im Vordergrund lassen.
4. Zunächst muss "WAITING FOR WINDOWS" erscheinen.
5. Danach Version-11-PC-Paket starten.

Version 11 verwendet versionCode 11 und kann über Version 10 installiert werden.
Beim ersten Start wird eine eventuell gespeicherte CLIENT-Rolle automatisch
entfernt. Die App ist für die nachweislich funktionierende Direktverbindung
absichtlich immer ein Bluetooth-SPP-Server.

Die unsichtbaren Rollen-/Geräte-Touchzonen im Gerätefoto gibt es nicht mehr.
Nur die sichtbaren Kopfzeilentasten LARGE VALUES / INSTRUMENT und EXIT sind
interaktiv.
